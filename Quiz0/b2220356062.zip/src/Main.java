public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, World! My name is Mert ERGÜN. This is absolutely not my first Java Code, but it is my first Java Code that I submit during BBM104 Spring 2023 Term.");
    }
}
