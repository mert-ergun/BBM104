public class InvalidChar extends Exception{
    public InvalidChar(String message){
        super(message);
    }
}
