public class EmptyInput extends Exception{
    public EmptyInput(String message){
        super(message);
    }
}
