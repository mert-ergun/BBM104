public class ParamNum extends Exception {
    public ParamNum(String message) {
        super(message);
    }
}
